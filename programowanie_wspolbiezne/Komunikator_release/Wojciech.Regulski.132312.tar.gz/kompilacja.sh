#/bin/bash

gcc -Wall inf132312_s.c inf132312_funkcje.c -o inf132312_s
gcc -Wall inf132312_k.c -o inf132312_k